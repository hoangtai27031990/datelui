
import React from 'react';
import { CalculationResult } from '../types';
import { formatDateVN } from '../utils/dateUtils';

interface ResultDisplayProps {
  result: CalculationResult | null;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  if (!result) return null;

  return (
    <div className="mt-8 bg-white rounded-2xl p-6 shadow-md border-t-4 border-green-500 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center">
        <span className="bg-green-100 text-green-600 p-2 rounded-lg mr-2">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </span>
        Kết quả tính toán
      </h2>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
          <span className="text-slate-600 font-medium">Tổng số ngày HSD:</span>
          <span className="text-slate-900 font-bold text-lg">{result.totalDays} ngày</span>
        </div>

        <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
          <span className="text-slate-600 font-medium">20% HSD (làm tròn):</span>
          <span className="text-slate-900 font-bold text-lg">{result.twentyPercentDays} ngày</span>
        </div>

        <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl text-center">
          <p className="text-blue-600 font-semibold mb-1 uppercase text-xs tracking-wider">Ngày cuối cùng được trưng bày</p>
          <p className="text-blue-900 font-black text-3xl">{formatDateVN(result.withdrawalDate)}</p>
        </div>
        
        <p className="text-xs text-slate-500 italic text-center">
          * Vui lòng lùi hàng khỏi quầy vào sáng ngày {formatDateVN(result.withdrawalDate)}
        </p>
      </div>
    </div>
  );
};

export default ResultDisplay;
