
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-blue-600 text-white py-6 px-4 shadow-lg rounded-b-3xl mb-8">
      <div className="max-w-md mx-auto flex items-center justify-center space-x-3">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
        <h1 className="text-2xl font-bold uppercase tracking-wide">Tính Ngày Lùi Hàng</h1>
      </div>
      <p className="text-center text-blue-100 mt-2 text-sm font-medium">Quy chuẩn trưng bày hàng hóa (20% HSD)</p>
    </header>
  );
};

export default Header;
