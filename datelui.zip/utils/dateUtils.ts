
/**
 * Formats a Date object to dd/mm/yyyy string
 */
export const formatDateVN = (date: Date): string => {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

/**
 * Calculates the withdrawal date based on NSX and HSD
 * Logic: WithdrawalDate = HSD - (20% of (HSD - NSX))
 */
export const calculateWithdrawal = (nsxStr: string, hsdStr: string) => {
  const nsxDate = new Date(nsxStr);
  const hsdDate = new Date(hsdStr);

  // Normalize to start of day for accurate day difference
  nsxDate.setHours(0, 0, 0, 0);
  hsdDate.setHours(0, 0, 0, 0);

  const diffMs = hsdDate.getTime() - nsxDate.getTime();
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  const twentyPercent = Math.floor(diffDays * 0.2);
  
  const withdrawalDate = new Date(hsdDate);
  withdrawalDate.setDate(hsdDate.getDate() - twentyPercent);

  return {
    totalDays: diffDays,
    twentyPercentDays: twentyPercent,
    withdrawalDate: withdrawalDate
  };
};
